
FUTURE BEEPS LITE EDITION is a free package that contains 37 sound effects taken from our 250+ sounds package « FUTURE BEEPS » ( available on the Asset Store : http://u3d.as/kyi )

« FUTURE BEEPS » is a carefully designed collection of royalty-free audio effects dedicated to futuristic beeps and bleeps, useful for futuristic UI interfaces , computer interactions, robotic communications, etc..

You can hear the full package version here : http://u3d.as/kyi

Files are organized in 5 categories :

* Simple_Beeps : simple electronic sounding beep sounds.

* Sweeps : short filtered effects.

* Repeating_Beeps : both short and long pulsating and repeating electronic sounds. Most sounds are suitable for looping 

* R2D2 : inspired by the sounds of a famous robot from an even more famous Sci-fi film, these bleeps are categorized in low and high pitched variations, as well as more complex variations.

* System_Failure : Sounds of computers and systems failing, going erratic, shutting down. Also includes phrases by female announcers like « Imminent system failure » , « Computer Malfunction « , etc..

All files in 16 bit, 44100 Hz, normalized stereo WAVs

Developed in collaboration with musician and sound designer Axel Zaren ( www.axelzaren.com )
Support at www.nirvanage.com
